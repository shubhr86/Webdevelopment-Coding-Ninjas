import app from "./index.js";


app.listen(3000, () =>{
    console.log("Server is listen at 3000 Port")
})