this project is awesome. 
well , i want to share something like there is lots of functions i actually not understand e.g "toggle/". i know TA will help me do most of the things where i stucked but i not take help from them.i rewatched videos beacuse seriously some of the concept i forgotted. i don't is it happens only with me or not.

some of the code i actually code with the help of internet like pagination, sorting. it is looks like cheating , so i share this with you.
