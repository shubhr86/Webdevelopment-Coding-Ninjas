import app from './index.js'

app.listen(3000,()=>{
  console.log("server is up at port 3000")   
})